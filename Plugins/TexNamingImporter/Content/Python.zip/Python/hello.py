import os, sys
#sys.path.append('E:/dev_e/tex_naming_importer/TexImporterProject/Plugins/TexNamingImporter/Content/Python')
import texture_config
import suffix_config

if __name__ == "__main__":
    tex_settings = texture_config.load_params_map_json("E:/dev_e/tex_naming_importer/TexImporterProject/Saved/ImportSettings.json")
    print(tex_settings)
    suffix_settings = suffix_config.load_texture_suffix_config("E:/dev_e/tex_naming_importer/TexImporterProject/Saved/SuffixSettings.json")
    print(suffix_settings)