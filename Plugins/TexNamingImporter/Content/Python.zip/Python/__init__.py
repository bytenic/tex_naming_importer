from suffix_config import *
from texture_config import *
from type_define import *